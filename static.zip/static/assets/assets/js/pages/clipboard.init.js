/**
 * Theme: Approx - Bootstrap 5 Responsive Admin Dashboard
 * Author: Mannatthemes
 * Clipboard Js
 */




var clipboard = new ClipboardJS('.btn');
