/**
 * Theme: Approx - Bootstrap 5 Responsive Admin Dashboard
 * Author: Mannatthemes
 * Project Create Js
 */

var elem = document.querySelector('input[name="startdate"]');
  new Datepicker(elem, {
});
var elem = document.querySelector('input[name="enddate"]');
  new Datepicker(elem, {
});