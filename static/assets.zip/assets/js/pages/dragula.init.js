/**
 * Theme: Approx - Bootstrap 5 Responsive Admin Dashboard
 * Author: Mannatthemes
 * Dragula Js
 */


 var iconTochange;
dragula([
    document.getElementById("project-list-start"),
    document.getElementById("project-list-center"),
    document.getElementById("project-list-end"), 
]);